package com.unimelb.swen30006.metromadness.exceptions;

public class PlatformCapacityException extends Exception {

	public PlatformCapacityException() {
		super("Error: No available platforms");
	}
	


}
